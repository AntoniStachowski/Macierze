package com.company;

import static java.lang.Math.*;

public abstract class Matrix implements IDoubleMatrix {
    private Shape shape;
    private double normOne;
    private double normInfinity;
    private double frobeniusNorm;

    public Matrix() {
        normOne = -1;
        normInfinity = -1;
        frobeniusNorm = -1;
    }

    @Override
    public double normOne() {
        if (normOne == -1) {
            normOne = calculateNormOne();
        }
        return normOne;
    }

    @Override
    public double normInfinity() {
        if (normInfinity == -1) {
            normInfinity = calculateNormInfinity();
        }
        return normInfinity;
    }

    @Override
    public double frobeniusNorm() {
        if (frobeniusNorm == -1) {
            frobeniusNorm = calculateFrobeniusNorm();
        }
        return frobeniusNorm;
    }

    protected void setShape(int x, int y) {
        shape = Shape.matrix(x, y);
    }

    protected void setShape(int x) {
        setShape(x, x);
    }

    public Shape shape() {
        return shape;
    }

    public abstract double getValue(int x, int y);

    protected void appendCopies(StringBuilder string, int copies, double value) {
        if (copies == 1) {
            string.append(value);
        } else if (copies == 2) {
            string.append(value + " " + value);
        } else if (copies > 2) {
            string.append(value + " ... " + value);
        }
    }

    @Override
    public Matrix asMatrix() {
        return this;
    }

    public double get(int x, int y) {
        shape.assertInShape(x, y);
        return getValue(x, y);
    }

    @Override
    public double[][] data() {
        double[][] values = new double[shape().rows][shape().columns];

        for (int i = 0; i < shape().rows; i++) {
            for (int j = 0; j < shape().columns; j++) {
                values[i][j] = get(i, j);
            }
        }

        return values;
    }

    public String toString() {
        double[][] values = data();
        StringBuilder string = new StringBuilder();
        string.append(shape().rows + "x" + shape().columns + '\n');


        for (int i = 0; i < shape().rows; i++) {
            for (int j = 0; j < shape().columns; j++) {
                string.append(values[i][j] + " ");
            }
            string.append('\n');
        }

        return string.toString();
    }

    public double calculateNormInfinity() {
        double max = Double.MIN_VALUE;
        double rowSum = 0;

        for (int i = 0; i < shape().rows; i++) {
            rowSum = 0;
            for (int j = 0; j < shape().columns; j++) {
                rowSum += abs(get(i, j));
            }
            max = max(max, rowSum);
        }

        return max;
    }

    public double calculateNormOne() {
        double max = Double.MIN_VALUE;
        double columnSum = 0;

        for (int i = 0; i < shape().columns; i++) {
            columnSum = 0;
            for (int j = 0; j < shape().rows; j++) {
                columnSum += abs(get(j, i));
            }
            max = max(max, columnSum);
        }

        return max;
    }

    public double calculateFrobeniusNorm() {
        double sum = 0;

        for (int i = 0; i < shape().rows; i++) {
            for (int j = 0; j < shape().columns; j++) {
                sum += get(i, j) * get(i, j);
            }
        }

        return sqrt(sum);
    }


    public Matrix plus(IDoubleMatrix matrix) {
        assert (shape.equals(matrix.shape()));

        if (matrix.asMatrix() != null) {
            return add(matrix.asMatrix());
        }

        return standardAdd(matrix);
    }

    public Matrix plus(double scalar) {
        return add(new Constant(shape(), scalar));
    }

    public Matrix minus(double scalar) {
        return plus(-scalar);
    }

    public Matrix minus(IDoubleMatrix matrix) {
        return plus(matrix.times(-1));
    }

    public Matrix standardAdd(IDoubleMatrix matrix) {
        double[][] sum = new double[matrix.shape().rows][matrix.shape().columns];

        for (int i = 0; i < matrix.shape().rows; i++) {
            for (int j = 0; j < matrix.shape().columns; j++) {
                sum[i][j] = get(i, j) + matrix.get(i, j);
            }
        }

        return new Full(sum);
    }

    protected abstract Matrix add(Matrix matrix);

    protected Matrix addAntidiagonal(Antidiagonal matrix) {
        return addPermutation(matrix);
    }

    protected abstract Matrix addColumn(Column matrix);

    protected abstract Matrix addConstant(Constant matrix);

    protected Matrix addDiagonal(Diagonal matrix) {
        return addPermutation(matrix);
    }

    protected Matrix addFull(Full matrix) {
        return standardAdd(matrix);
    }

    protected Matrix addIdentity(Identity matrix) {
        return addDiagonal(matrix);
    }

    protected abstract Matrix addRow(Row matrix);

    protected abstract Matrix addVector(Vector matrix);

    protected abstract Matrix addSparse(Sparse matrix);

    protected abstract Matrix addPermutation(Permutation matrix);

    public Matrix times(IDoubleMatrix matrix) {
        assert (this.shape.columns == matrix.shape().rows);

        if (matrix.asMatrix() != null) {
            return multiply(matrix.asMatrix());
        }

        return standardMultiply(matrix);
    }

    public Matrix standardMultiply(IDoubleMatrix matrix) {
        double[][] product = new double[shape().rows][matrix.shape().columns];

        for (int i = 0; i < shape().rows; i++) {
            for (int j = 0; j < matrix.shape().columns; j++) {
                for (int k = 0; k < shape().columns; k++) {
                    product[i][j] += get(i, k) * matrix.get(k, j);
                }
            }
        }

        return new Full(product);
    }

    public Matrix multiply(Matrix matrix) {
        return standardMultiply(matrix);
    }

    protected Matrix multiplyReverseAntidiagonal(Antidiagonal matrix) {
        return multiplyReversePermutation(matrix);
    }

    protected abstract Matrix multiplyReverseColumn(Column matrix);

    protected abstract Matrix multiplyReverseConstant(Constant matrix);

    protected Matrix multiplyReverseDiagonal(Diagonal matrix) {
        return multiplyReversePermutation(matrix);
    }

    protected abstract Matrix multiplyReverseFull(Full matrix);

    protected abstract Matrix multiplyReverseRow(Row matrix);

    protected Matrix multiplyReverseVector(Vector matrix) {
        return multiplyReverseFull(matrix);
    }

    protected abstract Matrix multiplyReverseSparse(Sparse matrix);

    protected abstract Matrix multiplyReversePermutation(Permutation matrix);

}
